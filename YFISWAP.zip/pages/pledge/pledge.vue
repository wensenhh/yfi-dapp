<template>
	<view class="container">
		<view class="topbar">
			<view :class="navbarindex === 1 ? 'active' : ''" @click="changetab(1)">{{$t('index.going')}}</view>
			<view :class="navbarindex === 2 ? 'active' : ''" @click="changetab(2)">{{$t('index.finished')}}</view>
		</view>
		<view class="sidebox">
			
			<view class="sidebox-box" v-for="item in 8">
				<view class="sidebox-box-onebox">
					<view class="sidebox-box-onebox-left">
						<view class="sidebox-box-onebox-left-title"><span>1000.00</span>CORE</view>
						<view class="sidebox-box-onebox-left-icon">
							<image src="../../static/jiahao.png" mode=""></image>
						</view>
						<view class="sidebox-box-onebox-left-title"><span>1000.00</span>YFI</view>
					</view>
					<view class="sidebox-box-onebox-right">{{$t('index.going')}}</view>
				</view>
				<view class="sidebox-box-twobox">
					<view>{{$t('index.total') + $t('index.earnings')}}<span>100.00</span></view>
					<view class="sidebox-box-twobox-centerbox"></view>
					<view>{{$t('index.keling') + $t('index.earnings')}}<span>100.00</span></view>
				</view>
				<view class="sidebox-box-threebox">
					<view class="sidebox-box-threebox-time">2022-09-10 00:00:00</view>
					<view class="sidebox-box-threebox-btn">{{$t('index.getqu')}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				navbarindex: 1
			};
		},
		methods: {
			changetab(i){
				this.navbarindex = i
			},
		}
	}
</script>

<style lang="scss">
	.container{
		background-color: #F8F8F8;
		>view{
			padding: 0 32rpx;
		}
		.topbar{
			padding: 24rpx 0;
			background-color: #ffffff;
			display: flex;
			width: 100%;
			>view{
				@include flexCenter;
				background-color: #F9F9F9;
				font-size: 30rpx;
				font-weight: bold;
				color: #000000;
				width: 50%;
				height: 80rpx;
				border-radius: 16rpx;
			}
			.active{
				background-color: #006AE3;
				color: #ffffff;
			}
		}
		.sidebox{
			padding-bottom: 96rpx;
			&-box{
				width: 100%;
				padding: 36rpx 24rpx;
				border-radius: 16rpx;
				background-color: #FFFFFF;
				display: flex;
				flex-direction: row;
				flex-direction: column;
				margin-top: 24rpx;
				&-onebox{
					display: flex;
					justify-content: space-between;
					align-items: center;
					&-left{
						display: flex;
						justify-content: inherit;
						align-items: center;
						width: 66%;
						&-title{
							font-size: 26rpx;
							color: #000000;
							span{
								font-size: 30rpx;
								color: #FF2929;
								margin-right: 6rpx;
							}
						}
						&-icon{
							width: 32rpx;
							height: 32rpx;
						}
					}
					&-right{
						@include flexCenter;
						width: 144rpx;
						height: 64rpx;
						background-color: rgba(11, 172, 47, 0.1);
						border-radius: 8rpx;
						color: #0BAC2F;
					}
				}
				&-twobox{
					@include flexGrid;
					margin-top: 52rpx;
					align-items: center;
					>view{
						font-size: 26rpx;
						color: rgba(0, 0, 0, 0.50);
						>span{
							font-size: 30rpx;
							color: #000000;
							padding-left: 8rpx;
						}
					}
					&-centerbox{
						width: 1rpx;
						height: 40rpx;
						background-color: rgba(0, 0, 0, 0.10);
						transform: scaleX(0.5)
					}
				}
				&-threebox{
					display: flex;
					justify-content: space-between;
					align-items: center;
					margin-top: 48rpx;
					&-time{
						font-size: 30rpx;
						color: rgba(0, 0, 0, 0.50);
					}
					&-btn{
						@include flexCenter;
						width: 128rpx;
						height: 64rpx;
						background-color: #006AE3;
						border-radius: 8rpx;
						color: #FFFFFF;
						font-size: 30rpx;
						font-weight: bold;
					}
				}
			}
			&-morebox{
				@include flexCenter;
				font-size: 26rpx;
				color: rgba(0, 0, 0, 0.50);
				margin-top: 40rpx;
			}
		}
	}
</style>
