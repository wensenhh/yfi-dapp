<template>
	<view class="container">
		<view class="pagewhite">
			<view class="headerbox">
				<view class="headerbox-left">
					<image src="../../static/YFI.png" mode=""></image>
					<view class="headerbox-left-title">
						YFISWAP
					</view>
				</view>
				<view class="headerbox-right" @click="openlangpop">
					<image src="../../static/langicon.png" mode=""></image>
				</view>
			</view>
			<view class="topbox">
				<view class="topbox-title">
					welcome!
				</view>
				<view class="topbox-address">
					{{address | hideaddress(address)}}
				</view>
			</view>
			<view class="noticebox">
				<view>
					<image src="../../static/noticeicon.png" mode=""></image>
				</view>
				<view class="noticebox-center">
					{{$t('index.online') + $t('index.notice')}}：系统包含商城首页、分类页、购物车、个人中心、产品详情、订单、客服、拼团、砍价、秒杀、分销、优惠券、签到、积分等完整的商城系统前端模板。欢迎大家下载体验
				</view>
				<view>
					<image src="../../static/jiant-you.png" mode=""></image>
				</view>
			</view>
			<view class="tabbarbox">
				<view class="active">{{$t('index.online') + $t('index.pledge')}}</view>
				<view>pledge</view>
			</view>
			<view class="pledgebox">
				<view class="pledgebox-item">
					<view class="pledgebox-item-toptt">
						CORE<image src="../../static/core.png" mode=""></image>
					</view>
					<view class="pledgebox-item-iptbox">
						<input type="number" :placeholder="$t('index.placeholder')">
					</view>
				</view>
				<view class="pledgebox-item">
					<view class="pledgebox-item-toptt">
						YFI<image src="../../static/YFI.png" mode=""></image>
					</view>
					<view class="pledgebox-item-iptbox">
						<input type="number" :placeholder="$t('index.placeholder')">
					</view>
				</view>
				<view class="pledgebox-plussign">
					<image src="../../static/jiahao.png" mode=""></image>
				</view>
				<view class="pledgebox-Time">
					<view :class="item.actived ? 'active' : ''" v-for="(item,i) in pledgeTime" @tap="changeTime(i)">{{item.value}}{{$t('index.day')}}</view>
				</view>
				<view class="pledgebox-btnbox">
					{{$t('index.authorization')}}
				</view>
			</view>
		</view>
		
		<view class="sidebox">
			<view class="tabbarbox">
				<view class="active">{{$t('index.my') + $t('index.pledge')}}</view>
				<view>pledge</view>
			</view>
			<view class="sidebox-box">
				<view class="sidebox-box-onebox">
					<view class="sidebox-box-onebox-left">
						<view class="sidebox-box-onebox-left-title"><span>1000.00</span>CORE</view>
						<view class="sidebox-box-onebox-left-icon">
							<image src="../../static/jiahao.png" mode=""></image>
						</view>
						<view class="sidebox-box-onebox-left-title"><span>1000.00</span>YFI</view>
					</view>
					<view class="sidebox-box-onebox-right">{{$t('index.going')}}</view>
				</view>
				<view class="sidebox-box-twobox">
					<view>{{$t('index.total') + $t('index.earnings')}}<span>100.00</span></view>
					<view class="sidebox-box-twobox-centerbox"></view>
					<view>{{$t('index.keling') + $t('index.earnings')}}<span>100.00</span></view>
				</view>
				<view class="sidebox-box-threebox">
					<view class="sidebox-box-threebox-time">2022-09-10 00:00:00</view>
					<view class="sidebox-box-threebox-btn">{{$t('index.getqu')}}</view>
				</view>
			</view>
			<view class="sidebox-morebox" @tap="navgoto('/pages/pledge/pledge')">
				{{$t('index.clickmore')}} >
			</view>
		</view>
		<uni-popup ref="langpopup" type="bottom">
			<view class="langbox">
				<view :class="nowlangcode == item.code ? 'active' : ''" v-for="item in locales" @click="onLocaleChange(item)">{{item.text}}</view>
				<view @click="$refs.langpopup.close()">
					{{$t('index.cancel')}}
				</view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue';
	import { Login, getNewNotice, getPledgeTimes } from '@/api/api.js';
	export default {
		components: {
			uniPopup,
		},
		data() {
			return {
				systemLocale: '',
				pledgeTime: [{
					value: 1,
					actived: true
				},{
					value: 10,
					actived: false
				},{
					value: 30,
					actived: false
				},{
					value: 100,
					actived: false
				}],
				address: uni.getStorageSync('address'),
				nowlangcode: ''
			}
		},
		computed: {
			locales() {
				return [{
						text: this.$t('locale.en'),
						code: 'en'
					},
					{
						text: this.$t('locale.zh-hans'),
						code: 'zh-Hans'
					},
					{
						text: this.$t('locale.zh-hant'),
						code: 'zh-Hant'
					}
				]
			}
		},
		async onLoad() {
			let systemInfo = uni.getSystemInfoSync();
			let that = this
			this.systemLocale = systemInfo.language;
			this.nowlangcode = uni.getLocale();
			this.isAndroid = systemInfo.platform.toLowerCase() === 'android';
			uni.onLocaleChange((e) => {
				this.nowlangcode = e.locale;
			})
			// 获取地址
			uni.setStorageSync('address', "");
			this.address = await this.$tools.getAddress();
			if (!!this.address) {
				uni.setStorageSync('address', this.address);
				this.getLogin(() => {
					that.getHomeNotice()//首页最新公告
					that.getPledgeTimes()//首页质押天数
				})
			}
		},
		methods: {
			getLogin(callback){
				Login({
					account: this.address
				}).then(res => {
					console.log('登录成功：', res.data)
					this.$tools.toast('登录成功~')
					uni.setStorageSync('token', res.data)
					return callback && callback()
				}).catch(err => {
					console.error('登录结果:', err);
				})
			},
			getHomeNotice(){
				getNewNotice().then(res => {
					console.log('公告：', res.data)
				}).catch(err => {
					console.error('结果:', err);
				})
			},
			getPledgeTimes(){
				getPledgeTimes().then(res => {
					console.log('质押天数：', res.data)
				}).catch(err => {
					console.error('结果:', err);
				})
			},
			openlangpop(){
				this.$refs.langpopup.open()
			},
			navgoto(url){
				uni.navigateTo({
					url: url
				})
			},
			changeTime(i){
				let arr = this.pledgeTime
				arr.forEach((item,index) => {
					index === i ? item.actived = true : item.actived = false
				})
				this.pledgeTime = arr
			},
			onLocaleChange(e) {
				if (this.isAndroid) {
					uni.showModal({
						content: this.$t('index.language-change-confirm'),
						success: (res) => {
							if (res.confirm) {
								uni.setLocale(e.code);
								this.nowlangcode = e.code;
								this.$i18n.locale = e.code;
								this.$refs.langpopup.close()
							}
						}
					})
				} else {
					uni.setLocale(e.code);
					this.nowlangcode = e.code;
					this.$i18n.locale = e.code;
					this.$refs.langpopup.close()
				}
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #F8F8F8;
		>view{
			padding: 0 32rpx;
		}
		.pagewhite{
			background-color: #FFFFFF;
			padding-bottom: 24rpx
		}
		.headerbox {
			@include flexBetween;
			padding: 16rpx 0;
			&-left {
				@include flexCenter;

				image {
					width: 64rpx;
					height: 64rpx;
					border-radius: 50%;
				}

				&-title {
					font-size: 34rpx;
					font-weight: bolder;
					color: #006AE3;
					margin-left: 16rpx;
				}
			}

			&-right {
				@include flexCenter;

				image {
					width: 48rpx;
					height: 48rpx;
					border-radius: 50%;
				}

			}
		}
		.topbox{
			@include flexLeftColumn;
			margin-top: 24rpx;
			&-title{
				font-size: 48rpx;
				font-weight: bolder;
				color: #006AE3;
			}
			&-address{
				font-size: 30rpx;
				color: #545454;
			}
		}
		.noticebox{
			@include threeflexLayout;
			background-color: #F8F8F8;
			width: 100%;
			height: 100rpx;
			border-radius: 16rpx;
			padding: 24rpx;
			margin-top: 48rpx;
			box-sizing: border-box;
			&-center{
				transition: 1s all;
				font-size: 30rpx;
				color: #000000;
				padding: 0 12rpx;
				padding-top: 18rpx;
				overflow-x: auto;
				white-space: nowrap;
			}
			>view{
				&:first-child{
					margin-right: 10rpx;
					image{
						width: 48rpx;
						height: 48rpx;
					}
				}
				
				&:last-child{
					margin-left: 10rpx;
					image{
						width: 40rpx;
						height: 40rpx;
					}
				}
			}
			
		}
		.tabbarbox{
			@include flexLeft;
			margin-top: 48rpx;
			>view{
				font-size: 34rpx;
				font-weight: 500;
				color: #000000;
				margin-right: 3%;
			}
			.active{
				color: #006AE3;
			}
		}
		.pledgebox{
			margin-top: 48rpx;
			position: relative;
			&-item{
				width: 100%;
				margin-bottom: 40rpx;
				&-toptt{
					@include flexLeft;
					font-size: 30rpx;
					font-weight: bold;
					color: #000000;
					display: flex;
					image{
						width: 32rpx;
						height: 32rpx;
						border-radius: 50%;
						margin-left: 8rpx;
					}
				}
				&-iptbox{
					@include flexCenter;
					width: 100%;
					height: 96rpx;
					background-color: #F8F8F8;
					border-radius: 16rpx;
					padding: 0 24rpx;
					margin-top: 20rpx;
					input{
						width: 100%;
					}
				}
			}
			&-plussign{
				position: absolute;
				top: 28%;
				left: 43%;
				image{
					border-radius: 50%;
					width: 72rpx;
					height: 72rpx;
				}
			}
			&-Time{
				@include flexGrid;
				margin-top: 24rpx;
				>view{
					@include flexCenter;
					width: calc(25% - 10px);
					height: 72rpx;
					background-color: #F8F8F8;
					border-radius: 8rpx;
					font-size: 30rpx;
					color: #000000;
				}
				.active{
					background-color: rgba(0, 106, 227, 0.1);
					color: #006AE3;
				}
			}
			&-btnbox{
				@include flexCenter;
				width: 100%;
				height: 96rpx;
				background-color: #006AE3;
				border-radius: 8rpx;
				font-size: 34rpx;
				font-weight: bold;
				color: #FFFFFF;
				margin-top: 40rpx;
			}
		}
		.sidebox{
			padding-bottom: 96rpx;
			&-box{
				width: 100%;
				padding: 36rpx 24rpx;
				border-radius: 16rpx;
				background-color: #FFFFFF;
				display: flex;
				flex-direction: row;
				flex-direction: column;
				margin-top: 24rpx;
				&-onebox{
					display: flex;
					justify-content: space-between;
					align-items: center;
					&-left{
						display: flex;
						justify-content: inherit;
						align-items: center;
						width: 66%;
						&-title{
							font-size: 26rpx;
							color: #000000;
							span{
								font-size: 30rpx;
								color: #FF2929;
								margin-right: 6rpx;
							}
						}
						&-icon{
							width: 32rpx;
							height: 32rpx;
						}
					}
					&-right{
						@include flexCenter;
						width: 144rpx;
						height: 64rpx;
						background-color: rgba(11, 172, 47, 0.1);
						border-radius: 8rpx;
						color: #0BAC2F;
					}
				}
				&-twobox{
					@include flexGrid;
					margin-top: 52rpx;
					align-items: center;
					>view{
						font-size: 26rpx;
						color: rgba(0, 0, 0, 0.50);
						>span{
							font-size: 30rpx;
							color: #000000;
							padding-left: 8rpx;
						}
					}
					&-centerbox{
						width: 1rpx;
						height: 40rpx;
						background-color: rgba(0, 0, 0, 0.10);
						transform: scaleX(0.5)
					}
				}
				&-threebox{
					display: flex;
					justify-content: space-between;
					align-items: center;
					margin-top: 48rpx;
					&-time{
						font-size: 30rpx;
						color: rgba(0, 0, 0, 0.50);
					}
					&-btn{
						@include flexCenter;
						width: 128rpx;
						height: 64rpx;
						background-color: #006AE3;
						border-radius: 8rpx;
						color: #FFFFFF;
						font-size: 30rpx;
						font-weight: bold;
					}
				}
			}
			&-morebox{
				@include flexCenter;
				font-size: 26rpx;
				color: rgba(0, 0, 0, 0.50);
				margin-top: 40rpx;
			}
		}
		.langbox{
			width: 100%;
			background-color: #FFFFFF;
			>view{
				@include flexCenter;
				height: 80rpx;
				border-bottom: 1px solid #f8f8f8;
				&:last-child{
					border: none;
					background-color: #f8f8f8;
				}
			}
			.active{
				color: red;
			}
		}
		::-webkit-scrollbar {
		    width: 0px;
		}
	}
</style>
