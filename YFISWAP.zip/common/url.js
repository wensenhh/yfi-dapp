 
//测试
const IP = 'yfi.xier.space';

//正式
// const IP = 'yfi.xier.space';


var ISHTTPS = false;

const webUrl = (ISHTTPS ? 'https://' : 'http://') + IP;
export default {
	webUrl: webUrl,
}
