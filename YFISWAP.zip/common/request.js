import Vue from 'vue'
import axios from 'axios'
import webUrl from './url.js'
import {
	Login
} from '@/api/api.js'

// create an axios instance
const service = axios.create({
	baseURL: webUrl.webUrl, // url = base url + request url
	//withCredentials: true, // send cookies when cross-domain requests 注意：withCredentials和后端配置的cross跨域不可同时使用
	timeout: 6000, // request timeout
	crossDomain: false,
	headers: {
		'Access-Control-Allow-Origin': '*',
		'Content-Type': 'application/x-www-form-urlencoded'
	}
})

// request拦截器,在请求之前做一些处理
service.interceptors.request.use(
	config => {
		// if (uni.getStorageSync('token')) {
		// 	// 给请求头添加user-token
		// 	config.headers["token"] = uni.getStorageSync('token');
		// }
		console.log('请求拦截成功')
		return config;
	},
	error => {
		console.log(error); // for debug
		return Promise.reject(error);
	}
);

//配置成功后的拦截器
service.interceptors.response.use(res => {
	if (res.data.code == 200) {
		return res.data
	} else if (res.data.code == 302) {
		Login({
			account: uni.getStorageSync('address')
		}).then(res => {
			console.log('登录成功：', res.data)
			this.$tools.toast('登录成功~')
			uni.setStorageSync('token', res.data)
		})
	} else {
		return Promise.reject(res.data.msg);
	}
}, error => {
	if (error.response.code) {
		switch (error.response.code) {
			case 401:
				break;
			default:
				break;
		}
	}
	return Promise.reject(error)
})




export default service
