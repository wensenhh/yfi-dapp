# hello-i18n

# en

A demo project for uni-app globalization

This template include uni-framework, manifest.json, pages.json, tabbar, Page, Component, API


# zh-hans

uni-app 国际化演示

包含 uni-framework、manifest.json、pages.json、tabbar、页面、组件、API

