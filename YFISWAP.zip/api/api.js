import request from '@/common/request.js'
 
/**
 * 授权登录
 * @param {*} data 
 */
export function Login(data) {
	return request({
		url: '/Login/register',
		method: 'post',
		params: {},
		data
	})
}

/**
 * 最新公告
 * @param {*} data 
 */
export function getNewNotice(data) {
	return request({
		url: '/Index/newslsat',
		method: 'post',
		params: {},
		data
	})
}

/**
 * 质押天数
 * @param {*} data 
 */
export function getPledgeTimes(data) {
	return request({
		url: '/Product/getIndexGoodsList',
		method: 'post',
		params: {},
		data
	})
}