<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	view {
		box-sizing: border-box;
	}

	uni-image {
		width: 100%;
		height: 100%;
	}

	button {
		margin-bottom: 15px;
	}
</style>
